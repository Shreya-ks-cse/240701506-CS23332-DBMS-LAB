package com.BloodVault.session;

public class Session {
    public static String currentHospitalId;
}
